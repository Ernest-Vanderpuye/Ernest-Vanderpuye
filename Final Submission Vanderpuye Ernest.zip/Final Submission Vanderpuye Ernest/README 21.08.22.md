# (Prosper Loan Dataset)
## by (Ernest Vanderpuye)


## Dataset

> This dataset contains one hundred and thirteen thousand nine hundred and thirty seven (113,937.00) loans given out to individuals and organizations. Each loan is characterized by eighty-one (81) variables, which give more details about each loan. Thus 113,937.00 rows and 81 columns. The rows representing individual observations and columns various attributes.

> This project is therefore going to explore this dataset using univariate, bivariate and multivariate visualizations to explore the various relationships that exist between these variables. The exploration and visualizations will be based around selected variables which i believe are key to help me answer my research questions. However this does not preclude that the other variables are less important.


## Summary of Findings

>  During my exploration of the prosper loan dataset these observations came to bear. I will summarize the key findings in the next few paragraphs just to give a clear picture of what high pointers are on this loan dataset.

> To begin with We can observe that majority of the loans that were issued out went to individuals who are in employment. This is rational since servicing of loans require periodic payments, therefore it will be prudent to award those loans to individuals who have a steady and high flow of monthly cashflow to service those loans. With retirees having a low and unsteady cash flows which majority go to cater for health care expenses the amount left after those payment will be little to service loans. We can see that 'Employed' tops the chart with 'Retirees' settling for the last position.


> In addition to the above we can tell that the loans are almost equally split between Homeowners and non homeowners. They almost share the spoils just that individuals with homes have a slight edge in terms of count but that edge is not that significant. This means that owning a property alone does not give one a undue advantage since the dataset is divided between the two categories. This could mean that this is considered together with other variables or attributes of the individual rather than in isolation.


> Furthermore we can see how righly skewed loan dataset is when we plot the 'Recommendations' attribute using a 'Countplot'. This clearly shows that a recommendation is not really a deciding or key variable since majority of the loans disbursed were to individuals that provided no recommendation whatsoever. Maybe the stress in getting recommendation may not be worth it unless there are other evidence to prove otherwise.

> Also more than half of the loan applicant that secured the money had stated during their loan application that they were going to use the loan amount for 'debt consolidation'. Meaning they have loans in other forms that they want to consolidate. Debt Consolidation is debt management or refinancing strategy that aims at reducing the monthly principal and interest payment. The servicing fees can also reduce considerably when debt are consolidated. We can clearly see that individuals hardly take loans to fund luxurious items like 'Boat', 'Motorcycle', 'Vacation', 'Weddings' and the likes since these expenses do not have the capability of generating cashflows in the future to service the loans.

> The 'donut pie-chart' tells us that for the majority of the loans issued out the applicant / borrower income source was not verified in any form. This is rather alarming since it's from the applicant's income which will be used to service the loan. With this been said it could be that the lender has other controls and other due diligence that it performs to ensure that most of this loans given to such individuals do not end up been Non performing loans.

> From the above scatter plots, the first thing is we can confidently say that both the Borrower Rate and Borrower Annual Percentage Rate move in the same direction. This means there is a positive correlation between the two variables. The relationship can be said to be a strong one thus as Borrower Annual Percentage increases so does the Borrower Rate.
> In adddition Borrower Rate' and 'Estimated loss' are positively correlated. This means that as the Borrower Rate or the interest rate that the lender charges on the loan increases the Estimated Loss on the loan amount is also going to increase. This is depicted by the upward movement from left to right.
> One of the the scatterplot also showed that the 'Prosper Score' is inversely correlated with the 'Borrower Rate'. That is to say a Higher prosper score translates into a lower interest rate 'Borrower Rate'. This correlation do not mean causation since there may be other factors that may be causing the lower Borrower Rate at a higher 'Prosper Score'.

> The above violin plot shows that on a average that loan applicants that own homes enjoy a lower Borrower Rate than applicants that do not own homes.A larger count of the home owners data fall below the 0.2 percentage point while loan applicants without homes can be seen to conentrated above the 0.2 percentage point.
> The other 'Violin Plot' depicts that the mean 'Original Loan Amount' is higher for individuals who are in employment than those who are partially or not employed at all that is 'Not employed' , 'Part-time' and 'Retired'. We can therefore say that to qualify for a higher loan amount your employment status will play a vital role.

> The two plots ; the Violin and Box plot both show that individual that had their income duly verified enjoy a comparatively lower Interest Rate than their fellow applicants whose income was not verified on. Looking at the box plot you realize that loan applicants whose income were verified are located below the 0.2 percent interest rate compared to those whose income were not verified were you can see that most of the data points relate to a higher interest rate thus above 0.2 percent.

> The'Heat Map' plotted also lets us see that majority of the loans disbursed are below '5,000.00' with a Borrower Rate between 0.25 and 0.3 percent. Thus most of the data points are conentrated there.

>The scatter plot which has a shape encoding to help plot the categorical element we can tell that most of the loans that were defaulted were within 5,000.00 which is quite surprising. One would have excepted that the larger loan amounts which are to the extreme right of the x-axis will be in default. 
> However a closer look at the scatterplot should tell you that althought the loan amount are small the interest / Borrower Rate on these loans are higher compared to the huge loans. This could be a reason.

> It can be observed from the scatterplot in the visualization that a large number of individuals who are employed occupy a high percentile with regards to not defaulting in terms of total trades as compared to those who are unemployed.

> The final scatter plots clearly shows that comparatively and across all levels of Total number of Prosper loans the lowest estimated return is occuppied by loan applicants with a low numeric prosper rating.


>

## Key Insights for Presentation

> So my presentation is centred on answering three questions which are.

> 1. Whether the majority of loans were issued out to applicants who own houses since a home is a good collateral on which a loan can be secured on

> 2. To establish whether a Higher Borrower rate has any form of relationship with Estimated loss on the loan and finally

> 3. Whether loans that were defaulted have any perculiar traits with respect to these two selected attributes or variables 'Borrower Rate' and 'Original Loan Amount'.

> To help me answer the first question i used a seaborn's countplot and it did just to the task. I made it clearly that there no biases towards people with homes since the loans are almost evenly distributed between the two factions.

> Then i went further to use a scatterplot since this time around the relationship that i was seeking to explore involed two quantitative variables that is 'Borrower Rate'  and 'Estimated Loss'. The scatterplot showed that this two variables a positively related depicted my an upward slope from left to right. This means as 'Borrower Rate' increases so does the 'Estimated Loss'.

> My final question was answered with the aid of a multivariate scatter plot with a little bit of shape encoding. We can tell that most of the loans that were defaulted were within 5,000.00 which is quite surprising. One would have expected that the larger loan amounts which are to the extreme right of the x-axis will be in default. However a closer look at the scatterplot should tell you that althought the loan amount are small the interest / Borrower Rate on these loans are higher compared to the huge loans. This could be a reason.












